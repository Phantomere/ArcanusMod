using Terraria.ModLoader;

namespace AetherMod
{
	public class AetherMod : Mod
	{

	}
}